import { Component, ViewChild } from '@angular/core';
import { ZenObservable } from 'zen-observable-ts';
import { APIService, DeleteBookingInput, Booking } from 'src/app/API.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatAccordion } from '@angular/material/expansion';

@Component({
  selector: 'app-list-booking',
  templateUrl: './list-booking.component.html',
  styleUrls: ['./list-booking.component.css']
})
export class ListBookingComponent {
  private subscription: ZenObservable.Subscription | null = null;
  @ViewChild(MatAccordion) accordion: MatAccordion | undefined;

  totalAmount: number = (125);

  public booking: Array<Booking> = [];
  constructor(private api: APIService) {

  }
  async ngOnInit() {
    this.api.ListBookings().then(event => {
      this.booking = event.items as Booking[];
    });
    this.subscription = this.api.OnCreateBookingListener().subscribe(
      (event: any) => {
        const newRestaurant = event.value.data.onCreateRestaurant;
        this.booking = [newRestaurant, ...this.booking];
      }
    );
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    this.subscription = null;
  }

  onDelete(id: string) {
    this.api.DeleteBooking({ id: id })
      .then((deleted_data) => {
        this.booking = this.booking.filter((emp) => emp.id != deleted_data.id)
      })
  }
}