import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { APIService, Booking } from 'src/app/API.service';
import { ZenObservable } from 'zen-observable-ts';



@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrls: ['./add-booking.component.css']
})
export class AddBookingComponent {
  public createForm: FormGroup;

  private subscription: ZenObservable.Subscription | null = null;

  public booking: Array<Booking> = [];

  constructor(private api: APIService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
      price: ['', Validators.required],
      noOfTickets: ['', Validators.required],
      totalAmount: ['', Validators.required],
    });
  }
  public onCreate(booking: Booking) {
    this.api
      .CreateBooking(booking)
      .then((event) => {
        console.log('item created!');
        this.createForm.reset();
      })
      .catch((e) => {
        console.log('error creating Booking...', e);
      });
  }

}
