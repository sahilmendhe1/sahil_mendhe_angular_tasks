export interface Flight {
    name: string;
    price: number;
    totalAmount: number;
    numberOfTickets: number;
}
export const initialFlightBookingState: Flight = {
    name: '',
    price: 0,
    totalAmount: 0,
    numberOfTickets: 0
};

