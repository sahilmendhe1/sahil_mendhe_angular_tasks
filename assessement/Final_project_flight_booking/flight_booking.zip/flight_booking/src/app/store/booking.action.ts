import { createAction, props } from '@ngrx/store';

export const setName = createAction(
    '[Flight Booking] Set Name',
    props<{ name: string }>()
);

export const setPrice = createAction(
    '[Flight Booking] Set Price',
    props<{ price: number }>()
);

export const setTotalAmount = createAction(
    '[Flight Booking] Set Total Amount',
    props<{ totalAmount: number }>()
);

export const setNumberOfTickets = createAction(
    '[Flight Booking] Set Number Of Tickets',
    props<{ numberOfTickets: number }>()
);
