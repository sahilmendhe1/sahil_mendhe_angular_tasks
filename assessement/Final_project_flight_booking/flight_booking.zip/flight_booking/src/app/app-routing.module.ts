import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookingComponent } from './components/add-booking/add-booking.component';
import { DashboardsComponent } from './components/dashboards/dashboards.component';
import { HomeComponent } from './components/home/home.component';
import { ListBookingComponent } from './components/list-booking/list-booking.component';
import { UpdateBookingComponent } from './components/update-booking/update-booking.component';

const routes: Routes = [
  { path: 'dashboards', component: DashboardsComponent },
  { path: 'addbooking', component: AddBookingComponent },
  { path: 'updatebooking', component: UpdateBookingComponent },
  { path: 'listbooking', component: ListBookingComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
