/* tslint:disable */
/* eslint-disable */
//  This file was automatically generated and should not be edited.
import { Injectable } from "@angular/core";
import API, { graphqlOperation, GraphQLResult } from "@aws-amplify/api-graphql";
import { Observable } from "zen-observable-ts";

export interface SubscriptionResponse<T> {
  value: GraphQLResult<T>;
}

export type __SubscriptionContainer = {
  onCreateEmployee: OnCreateEmployeeSubscription;
  onUpdateEmployee: OnUpdateEmployeeSubscription;
  onDeleteEmployee: OnDeleteEmployeeSubscription;
  onCreateTask: OnCreateTaskSubscription;
  onUpdateTask: OnUpdateTaskSubscription;
  onDeleteTask: OnDeleteTaskSubscription;
};

export type CreateEmployeeInput = {
  id?: string | null;
  name: string;
};

export type ModelEmployeeConditionInput = {
  name?: ModelStringInput | null;
  and?: Array<ModelEmployeeConditionInput | null> | null;
  or?: Array<ModelEmployeeConditionInput | null> | null;
  not?: ModelEmployeeConditionInput | null;
};

export type ModelStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export enum ModelAttributeTypes {
  binary = "binary",
  binarySet = "binarySet",
  bool = "bool",
  list = "list",
  map = "map",
  number = "number",
  numberSet = "numberSet",
  string = "string",
  stringSet = "stringSet",
  _null = "_null"
}

export type ModelSizeInput = {
  ne?: number | null;
  eq?: number | null;
  le?: number | null;
  lt?: number | null;
  ge?: number | null;
  gt?: number | null;
  between?: Array<number | null> | null;
};

export type Employee = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: ModelTaskConnection | null;
  createdAt: string;
  updatedAt: string;
};

export type ModelTaskConnection = {
  __typename: "ModelTaskConnection";
  items: Array<Task | null>;
  nextToken?: string | null;
};

export type Task = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: Employee | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type UpdateEmployeeInput = {
  id: string;
  name?: string | null;
};

export type DeleteEmployeeInput = {
  id: string;
};

export type CreateTaskInput = {
  id?: string | null;
  name: string;
  dueDate?: string | null;
  employeeTasksId?: string | null;
};

export type ModelTaskConditionInput = {
  name?: ModelStringInput | null;
  dueDate?: ModelStringInput | null;
  and?: Array<ModelTaskConditionInput | null> | null;
  or?: Array<ModelTaskConditionInput | null> | null;
  not?: ModelTaskConditionInput | null;
  employeeTasksId?: ModelIDInput | null;
};

export type ModelIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  attributeExists?: boolean | null;
  attributeType?: ModelAttributeTypes | null;
  size?: ModelSizeInput | null;
};

export type UpdateTaskInput = {
  id: string;
  name?: string | null;
  dueDate?: string | null;
  employeeTasksId?: string | null;
};

export type DeleteTaskInput = {
  id: string;
};

export type SearchableEmployeeFilterInput = {
  id?: SearchableIDFilterInput | null;
  name?: SearchableStringFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  and?: Array<SearchableEmployeeFilterInput | null> | null;
  or?: Array<SearchableEmployeeFilterInput | null> | null;
  not?: SearchableEmployeeFilterInput | null;
};

export type SearchableIDFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableStringFilterInput = {
  ne?: string | null;
  gt?: string | null;
  lt?: string | null;
  gte?: string | null;
  lte?: string | null;
  eq?: string | null;
  match?: string | null;
  matchPhrase?: string | null;
  matchPhrasePrefix?: string | null;
  multiMatch?: string | null;
  exists?: boolean | null;
  wildcard?: string | null;
  regexp?: string | null;
  range?: Array<string | null> | null;
};

export type SearchableEmployeeSortInput = {
  field?: SearchableEmployeeSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableEmployeeSortableFields {
  id = "id",
  name = "name",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export enum SearchableSortDirection {
  asc = "asc",
  desc = "desc"
}

export type SearchableEmployeeAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableEmployeeAggregateField;
};

export enum SearchableAggregateType {
  terms = "terms",
  avg = "avg",
  min = "min",
  max = "max",
  sum = "sum"
}

export enum SearchableEmployeeAggregateField {
  id = "id",
  name = "name",
  createdAt = "createdAt",
  updatedAt = "updatedAt"
}

export type SearchableEmployeeConnection = {
  __typename: "SearchableEmployeeConnection";
  items: Array<Employee | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type SearchableAggregateResult = {
  __typename: "SearchableAggregateResult";
  name: string;
  result?: SearchableAggregateGenericResult | null;
};

export type SearchableAggregateGenericResult =
  | SearchableAggregateScalarResult
  | SearchableAggregateBucketResult;

export type SearchableAggregateScalarResult = {
  __typename: "SearchableAggregateScalarResult";
  value: number;
};

export type SearchableAggregateBucketResult = {
  __typename: "SearchableAggregateBucketResult";
  buckets?: Array<SearchableAggregateBucketResultItem | null> | null;
};

export type SearchableAggregateBucketResultItem = {
  __typename: "SearchableAggregateBucketResultItem";
  key: string;
  doc_count: number;
};

export type SearchableTaskFilterInput = {
  id?: SearchableIDFilterInput | null;
  name?: SearchableStringFilterInput | null;
  dueDate?: SearchableStringFilterInput | null;
  createdAt?: SearchableStringFilterInput | null;
  updatedAt?: SearchableStringFilterInput | null;
  employeeTasksId?: SearchableIDFilterInput | null;
  and?: Array<SearchableTaskFilterInput | null> | null;
  or?: Array<SearchableTaskFilterInput | null> | null;
  not?: SearchableTaskFilterInput | null;
};

export type SearchableTaskSortInput = {
  field?: SearchableTaskSortableFields | null;
  direction?: SearchableSortDirection | null;
};

export enum SearchableTaskSortableFields {
  id = "id",
  name = "name",
  dueDate = "dueDate",
  createdAt = "createdAt",
  updatedAt = "updatedAt",
  employeeTasksId = "employeeTasksId"
}

export type SearchableTaskAggregationInput = {
  name: string;
  type: SearchableAggregateType;
  field: SearchableTaskAggregateField;
};

export enum SearchableTaskAggregateField {
  id = "id",
  name = "name",
  dueDate = "dueDate",
  createdAt = "createdAt",
  updatedAt = "updatedAt",
  employeeTasksId = "employeeTasksId"
}

export type SearchableTaskConnection = {
  __typename: "SearchableTaskConnection";
  items: Array<Task | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<SearchableAggregateResult | null>;
};

export type ModelEmployeeFilterInput = {
  id?: ModelIDInput | null;
  name?: ModelStringInput | null;
  and?: Array<ModelEmployeeFilterInput | null> | null;
  or?: Array<ModelEmployeeFilterInput | null> | null;
  not?: ModelEmployeeFilterInput | null;
};

export type ModelEmployeeConnection = {
  __typename: "ModelEmployeeConnection";
  items: Array<Employee | null>;
  nextToken?: string | null;
};

export type ModelTaskFilterInput = {
  id?: ModelIDInput | null;
  name?: ModelStringInput | null;
  dueDate?: ModelStringInput | null;
  and?: Array<ModelTaskFilterInput | null> | null;
  or?: Array<ModelTaskFilterInput | null> | null;
  not?: ModelTaskFilterInput | null;
  employeeTasksId?: ModelIDInput | null;
};

export type ModelSubscriptionEmployeeFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  name?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionEmployeeFilterInput | null> | null;
  or?: Array<ModelSubscriptionEmployeeFilterInput | null> | null;
};

export type ModelSubscriptionIDInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionStringInput = {
  ne?: string | null;
  eq?: string | null;
  le?: string | null;
  lt?: string | null;
  ge?: string | null;
  gt?: string | null;
  contains?: string | null;
  notContains?: string | null;
  between?: Array<string | null> | null;
  beginsWith?: string | null;
  in?: Array<string | null> | null;
  notIn?: Array<string | null> | null;
};

export type ModelSubscriptionTaskFilterInput = {
  id?: ModelSubscriptionIDInput | null;
  name?: ModelSubscriptionStringInput | null;
  dueDate?: ModelSubscriptionStringInput | null;
  and?: Array<ModelSubscriptionTaskFilterInput | null> | null;
  or?: Array<ModelSubscriptionTaskFilterInput | null> | null;
};

export type CreateEmployeeMutation = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type UpdateEmployeeMutation = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type DeleteEmployeeMutation = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type CreateTaskMutation = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type UpdateTaskMutation = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type DeleteTaskMutation = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type SearchEmployeesQuery = {
  __typename: "SearchableEmployeeConnection";
  items: Array<{
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type SearchTasksQuery = {
  __typename: "SearchableTaskConnection";
  items: Array<{
    __typename: "Task";
    id: string;
    name: string;
    dueDate?: string | null;
    employee?: {
      __typename: "Employee";
      id: string;
      name: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    createdAt: string;
    updatedAt: string;
    employeeTasksId?: string | null;
  } | null>;
  nextToken?: string | null;
  total?: number | null;
  aggregateItems: Array<{
    __typename: "SearchableAggregateResult";
    name: string;
    result:
      | (
          | {
              __typename: "SearchableAggregateScalarResult";
              value: number;
            }
          | {
              __typename: "SearchableAggregateBucketResult";
              buckets?: Array<{
                __typename: string;
                key: string;
                doc_count: number;
              } | null> | null;
            }
        )
      | null;
  } | null>;
};

export type GetEmployeeQuery = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type ListEmployeesQuery = {
  __typename: "ModelEmployeeConnection";
  items: Array<{
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null>;
  nextToken?: string | null;
};

export type GetTaskQuery = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type ListTasksQuery = {
  __typename: "ModelTaskConnection";
  items: Array<{
    __typename: "Task";
    id: string;
    name: string;
    dueDate?: string | null;
    employee?: {
      __typename: "Employee";
      id: string;
      name: string;
      createdAt: string;
      updatedAt: string;
    } | null;
    createdAt: string;
    updatedAt: string;
    employeeTasksId?: string | null;
  } | null>;
  nextToken?: string | null;
};

export type OnCreateEmployeeSubscription = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnUpdateEmployeeSubscription = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnDeleteEmployeeSubscription = {
  __typename: "Employee";
  id: string;
  name: string;
  tasks?: {
    __typename: "ModelTaskConnection";
    items: Array<{
      __typename: "Task";
      id: string;
      name: string;
      dueDate?: string | null;
      createdAt: string;
      updatedAt: string;
      employeeTasksId?: string | null;
    } | null>;
    nextToken?: string | null;
  } | null;
  createdAt: string;
  updatedAt: string;
};

export type OnCreateTaskSubscription = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type OnUpdateTaskSubscription = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

export type OnDeleteTaskSubscription = {
  __typename: "Task";
  id: string;
  name: string;
  dueDate?: string | null;
  employee?: {
    __typename: "Employee";
    id: string;
    name: string;
    tasks?: {
      __typename: "ModelTaskConnection";
      nextToken?: string | null;
    } | null;
    createdAt: string;
    updatedAt: string;
  } | null;
  createdAt: string;
  updatedAt: string;
  employeeTasksId?: string | null;
};

@Injectable({
  providedIn: "root"
})
export class APIService {
  async CreateEmployee(
    input: CreateEmployeeInput,
    condition?: ModelEmployeeConditionInput
  ): Promise<CreateEmployeeMutation> {
    const statement = `mutation CreateEmployee($input: CreateEmployeeInput!, $condition: ModelEmployeeConditionInput) {
        createEmployee(input: $input, condition: $condition) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateEmployeeMutation>response.data.createEmployee;
  }
  async UpdateEmployee(
    input: UpdateEmployeeInput,
    condition?: ModelEmployeeConditionInput
  ): Promise<UpdateEmployeeMutation> {
    const statement = `mutation UpdateEmployee($input: UpdateEmployeeInput!, $condition: ModelEmployeeConditionInput) {
        updateEmployee(input: $input, condition: $condition) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateEmployeeMutation>response.data.updateEmployee;
  }
  async DeleteEmployee(
    input: DeleteEmployeeInput,
    condition?: ModelEmployeeConditionInput
  ): Promise<DeleteEmployeeMutation> {
    const statement = `mutation DeleteEmployee($input: DeleteEmployeeInput!, $condition: ModelEmployeeConditionInput) {
        deleteEmployee(input: $input, condition: $condition) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteEmployeeMutation>response.data.deleteEmployee;
  }
  async CreateTask(
    input: CreateTaskInput,
    condition?: ModelTaskConditionInput
  ): Promise<CreateTaskMutation> {
    const statement = `mutation CreateTask($input: CreateTaskInput!, $condition: ModelTaskConditionInput) {
        createTask(input: $input, condition: $condition) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <CreateTaskMutation>response.data.createTask;
  }
  async UpdateTask(
    input: UpdateTaskInput,
    condition?: ModelTaskConditionInput
  ): Promise<UpdateTaskMutation> {
    const statement = `mutation UpdateTask($input: UpdateTaskInput!, $condition: ModelTaskConditionInput) {
        updateTask(input: $input, condition: $condition) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <UpdateTaskMutation>response.data.updateTask;
  }
  async DeleteTask(
    input: DeleteTaskInput,
    condition?: ModelTaskConditionInput
  ): Promise<DeleteTaskMutation> {
    const statement = `mutation DeleteTask($input: DeleteTaskInput!, $condition: ModelTaskConditionInput) {
        deleteTask(input: $input, condition: $condition) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      input
    };
    if (condition) {
      gqlAPIServiceArguments.condition = condition;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <DeleteTaskMutation>response.data.deleteTask;
  }
  async SearchEmployees(
    filter?: SearchableEmployeeFilterInput,
    sort?: Array<SearchableEmployeeSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableEmployeeAggregationInput | null>
  ): Promise<SearchEmployeesQuery> {
    const statement = `query SearchEmployees($filter: SearchableEmployeeFilterInput, $sort: [SearchableEmployeeSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableEmployeeAggregationInput]) {
        searchEmployees(
          filter: $filter
          sort: $sort
          limit: $limit
          nextToken: $nextToken
          from: $from
          aggregates: $aggregates
        ) {
          __typename
          items {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchEmployeesQuery>response.data.searchEmployees;
  }
  async SearchTasks(
    filter?: SearchableTaskFilterInput,
    sort?: Array<SearchableTaskSortInput | null>,
    limit?: number,
    nextToken?: string,
    from?: number,
    aggregates?: Array<SearchableTaskAggregationInput | null>
  ): Promise<SearchTasksQuery> {
    const statement = `query SearchTasks($filter: SearchableTaskFilterInput, $sort: [SearchableTaskSortInput], $limit: Int, $nextToken: String, $from: Int, $aggregates: [SearchableTaskAggregationInput]) {
        searchTasks(
          filter: $filter
          sort: $sort
          limit: $limit
          nextToken: $nextToken
          from: $from
          aggregates: $aggregates
        ) {
          __typename
          items {
            __typename
            id
            name
            dueDate
            employee {
              __typename
              id
              name
              createdAt
              updatedAt
            }
            createdAt
            updatedAt
            employeeTasksId
          }
          nextToken
          total
          aggregateItems {
            __typename
            name
            result {
              __typename
              ... on SearchableAggregateScalarResult {
                value
              }
              ... on SearchableAggregateBucketResult {
                buckets {
                  __typename
                  key
                  doc_count
                }
              }
            }
          }
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (sort) {
      gqlAPIServiceArguments.sort = sort;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    if (from) {
      gqlAPIServiceArguments.from = from;
    }
    if (aggregates) {
      gqlAPIServiceArguments.aggregates = aggregates;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <SearchTasksQuery>response.data.searchTasks;
  }
  async GetEmployee(id: string): Promise<GetEmployeeQuery> {
    const statement = `query GetEmployee($id: ID!) {
        getEmployee(id: $id) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetEmployeeQuery>response.data.getEmployee;
  }
  async ListEmployees(
    filter?: ModelEmployeeFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListEmployeesQuery> {
    const statement = `query ListEmployees($filter: ModelEmployeeFilterInput, $limit: Int, $nextToken: String) {
        listEmployees(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListEmployeesQuery>response.data.listEmployees;
  }
  async GetTask(id: string): Promise<GetTaskQuery> {
    const statement = `query GetTask($id: ID!) {
        getTask(id: $id) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {
      id
    };
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <GetTaskQuery>response.data.getTask;
  }
  async ListTasks(
    filter?: ModelTaskFilterInput,
    limit?: number,
    nextToken?: string
  ): Promise<ListTasksQuery> {
    const statement = `query ListTasks($filter: ModelTaskFilterInput, $limit: Int, $nextToken: String) {
        listTasks(filter: $filter, limit: $limit, nextToken: $nextToken) {
          __typename
          items {
            __typename
            id
            name
            dueDate
            employee {
              __typename
              id
              name
              createdAt
              updatedAt
            }
            createdAt
            updatedAt
            employeeTasksId
          }
          nextToken
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    if (limit) {
      gqlAPIServiceArguments.limit = limit;
    }
    if (nextToken) {
      gqlAPIServiceArguments.nextToken = nextToken;
    }
    const response = (await API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    )) as any;
    return <ListTasksQuery>response.data.listTasks;
  }
  OnCreateEmployeeListener(
    filter?: ModelSubscriptionEmployeeFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateEmployee">>
  > {
    const statement = `subscription OnCreateEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
        onCreateEmployee(filter: $filter) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateEmployee">>
    >;
  }

  OnUpdateEmployeeListener(
    filter?: ModelSubscriptionEmployeeFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateEmployee">>
  > {
    const statement = `subscription OnUpdateEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
        onUpdateEmployee(filter: $filter) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateEmployee">>
    >;
  }

  OnDeleteEmployeeListener(
    filter?: ModelSubscriptionEmployeeFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteEmployee">>
  > {
    const statement = `subscription OnDeleteEmployee($filter: ModelSubscriptionEmployeeFilterInput) {
        onDeleteEmployee(filter: $filter) {
          __typename
          id
          name
          tasks {
            __typename
            items {
              __typename
              id
              name
              dueDate
              createdAt
              updatedAt
              employeeTasksId
            }
            nextToken
          }
          createdAt
          updatedAt
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteEmployee">>
    >;
  }

  OnCreateTaskListener(
    filter?: ModelSubscriptionTaskFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateTask">>
  > {
    const statement = `subscription OnCreateTask($filter: ModelSubscriptionTaskFilterInput) {
        onCreateTask(filter: $filter) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onCreateTask">>
    >;
  }

  OnUpdateTaskListener(
    filter?: ModelSubscriptionTaskFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateTask">>
  > {
    const statement = `subscription OnUpdateTask($filter: ModelSubscriptionTaskFilterInput) {
        onUpdateTask(filter: $filter) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onUpdateTask">>
    >;
  }

  OnDeleteTaskListener(
    filter?: ModelSubscriptionTaskFilterInput
  ): Observable<
    SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteTask">>
  > {
    const statement = `subscription OnDeleteTask($filter: ModelSubscriptionTaskFilterInput) {
        onDeleteTask(filter: $filter) {
          __typename
          id
          name
          dueDate
          employee {
            __typename
            id
            name
            tasks {
              __typename
              nextToken
            }
            createdAt
            updatedAt
          }
          createdAt
          updatedAt
          employeeTasksId
        }
      }`;
    const gqlAPIServiceArguments: any = {};
    if (filter) {
      gqlAPIServiceArguments.filter = filter;
    }
    return API.graphql(
      graphqlOperation(statement, gqlAPIServiceArguments)
    ) as Observable<
      SubscriptionResponse<Pick<__SubscriptionContainer, "onDeleteTask">>
    >;
  }
}
