import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { API, graphqlOperation } from 'aws-amplify';
import { APIService, Employee } from 'src/app/API.service';
import { ZenObservable } from 'zen-observable-ts';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent {

  employee!: Employee;
  public employeeForm!: FormGroup;

  private subscription: ZenObservable.Subscription | null = null;

  public employees: Array<Employee> = [];
  updateEmployee: any;

  constructor(private api: APIService, private fb: FormBuilder, private route: ActivatedRoute) {
    this.employeeForm = this.fb.group({
      name: ['', Validators.required]
    });
  }


  async onSubmit() {
    const updatedEmployee: Employee = {
      name: this.employeeForm.value.firstName,
      __typename: 'Employee',
      id: '',
      createdAt: '',
      updatedAt: ''
    };

    await this.updateEmployee(updatedEmployee);
  }
}

