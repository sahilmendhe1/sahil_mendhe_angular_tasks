import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ZenObservable } from 'zen-observable-ts';
import { MatAccordion } from '@angular/material/expansion';
import { APIService, Employee } from 'src/app/API.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {

  public createForm: FormGroup;

  private subscription: ZenObservable.Subscription | null = null;

  public employees: Array<Employee> = [];

  constructor(private api: APIService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
    });
  }

  public onCreate(employee: Employee) {
    this.api
      .CreateEmployee(employee)
      .then(() => {
        console.log('item created!');
        this.createForm.reset();
      })
      .catch((e) => {
        console.log('error creating restaurant...', e);
      });
  }


  async ngOnInit() {
    this.api.ListEmployees().then(event => {
      this.employees = event.items as Employee[];
    });

    /* subscribe to new restaurants being created */
    this.subscription = this.api.OnCreateEmployeeListener().subscribe(
      (event: any) => {
        const newRestaurant = event.value.data.onCreateRestaurant;
        this.employees = [newRestaurant, ...this.employees];
      }
    );
  }
}
