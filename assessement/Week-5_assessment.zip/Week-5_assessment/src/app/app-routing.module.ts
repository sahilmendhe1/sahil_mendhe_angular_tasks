import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { AddTaskComponent } from './components/add-task/add-task.component';
import { UpdateEmployeeComponent } from './components/update-employee/update-employee.component';
import { UpdateTaskComponent } from './components/update-task/update-task.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {
    path: "home", component: HomeComponent
  },
  {
    path: "addEmployee", component: AddEmployeeComponent
  },
  {
    path: "updateEmployee", component: UpdateEmployeeComponent
  }
  ,
  {
    path: "addTask", component: AddTaskComponent
  }
  ,
  {
    path: "updateTask", component: UpdateTaskComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
